var searchData=
[
  ['latest_5fimu_0',['latest_imu',['../classgoat__vesc_1_1VescClient.html#ad03d52bef002bc0bd47165d6d2764890',1,'goat_vesc::VescClient']]],
  ['latest_5fmotor_5fstate_1',['latest_motor_state',['../classgoat__vesc_1_1VescClient.html#a1b6875c1ca67891b7abfc41cd7419755',1,'goat_vesc::VescClient']]],
  ['layering_2',['Protocol Layering',['../md_docs_2src_2ARCHITECTURE.html#autotoc_md11',1,'']]],
  ['lifecycle_3',['Discovery And Lifecycle',['../md_docs_2src_2OPERATOR__QUICK__REFERENCE.html#autotoc_md26',1,'']]],
  ['long_4',['Long',['../protocol__ids_8hpp.html#a6b342601cc6e0b6392c58113f3647aeca8394f0347c184cf156ac5924dccb773b',1,'goat_vesc']]]
];
