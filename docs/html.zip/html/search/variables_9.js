var searchData=
[
  ['open_5fserial_5ffn_0',['open_serial_fn',['../structgoat__vesc_1_1VescConfig.html#a486bc19f5e65809c60e6fcf6f4137028',1,'goat_vesc::VescConfig']]]
];
