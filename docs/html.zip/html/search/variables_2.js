var searchData=
[
  ['command_5fwatchdog_5faction_0',['command_watchdog_action',['../structgoat__vesc_1_1VescConfig.html#a1ffeae5fd519393859ae3d44a6a875f9',1,'goat_vesc::VescConfig::command_watchdog_action'],['../structgoat__vesc_1_1VescClientConfigSnapshot.html#a98e5fa9a8e7a29dd6c83afab236b8092',1,'goat_vesc::VescClientConfigSnapshot::command_watchdog_action']]],
  ['command_5fwatchdog_5fbrake_5fcurrent_1',['command_watchdog_brake_current',['../structgoat__vesc_1_1VescConfig.html#a790b0621d6147676a9f305957dd9df51',1,'goat_vesc::VescConfig::command_watchdog_brake_current'],['../structgoat__vesc_1_1VescClientConfigSnapshot.html#a6c8405626f1721587fc4651f5f269356',1,'goat_vesc::VescClientConfigSnapshot::command_watchdog_brake_current']]],
  ['command_5fwatchdog_5ftimeout_2',['command_watchdog_timeout',['../structgoat__vesc_1_1VescConfig.html#a54dcc960dd67cd9a096008093dd63bba',1,'goat_vesc::VescConfig::command_watchdog_timeout'],['../structgoat__vesc_1_1VescClientConfigSnapshot.html#a78fda557e4fad571eb8bd4e1b48d8d51',1,'goat_vesc::VescClientConfigSnapshot::command_watchdog_timeout']]],
  ['current_5fin_3',['current_in',['../structgoat__vesc_1_1VescMotorState.html#ac87ca2d89c34aac9ff2e4a9207684d47',1,'goat_vesc::VescMotorState']]],
  ['current_5fmotor_4',['current_motor',['../structgoat__vesc_1_1VescMotorState.html#a8730a39a82e4c164027476ffab83f287',1,'goat_vesc::VescMotorState']]]
];
