var indexSectionsWithContent =
{
  0: "abcdefghijklmnopqrstvwy~",
  1: "fsv",
  2: "eptv",
  3: "bcdfiloprsv~",
  4: "abcdfgikmopqrstvwy",
  5: "fimp",
  6: "cv",
  7: "abcdefgjlmpqrstvwy",
  8: "abcgnoqr"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues",
  8: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerations",
  7: "Enumerator",
  8: "Pages"
};

