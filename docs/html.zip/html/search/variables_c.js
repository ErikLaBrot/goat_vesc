var searchData=
[
  ['roll_0',['roll',['../structgoat__vesc_1_1VescIMUData.html#a3bb002eda4d99cd248302e29e9c3a0b1',1,'goat_vesc::VescIMUData']]],
  ['rpm_1',['rpm',['../structgoat__vesc_1_1VescMotorState.html#a250afa196d756583f05df8cce5e941bb',1,'goat_vesc::VescMotorState']]]
];
