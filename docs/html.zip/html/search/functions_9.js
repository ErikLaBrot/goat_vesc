var searchData=
[
  ['set_5fcurrent_0',['set_current',['../classgoat__vesc_1_1VescClient.html#a08dfd9c90b749ede5b31011a1496fa3c',1,'goat_vesc::VescClient']]],
  ['set_5fcurrent_5fbrake_1',['set_current_brake',['../classgoat__vesc_1_1VescClient.html#a0cba09e59f08b96822079cfafbf90601',1,'goat_vesc::VescClient']]],
  ['set_5fduty_2',['set_duty',['../classgoat__vesc_1_1VescClient.html#a7f183ec4e5e41ec0474d2e092c54eb14',1,'goat_vesc::VescClient']]],
  ['set_5fimu_5fpoll_5finterval_3',['set_imu_poll_interval',['../classgoat__vesc_1_1VescClient.html#a9eb7acc23f20cf2c94c44849da516de8',1,'goat_vesc::VescClient']]],
  ['set_5fmotor_5fpoll_5finterval_4',['set_motor_poll_interval',['../classgoat__vesc_1_1VescClient.html#a5828f3f714e886449244bef353248ecf',1,'goat_vesc::VescClient']]],
  ['set_5frpm_5',['set_rpm',['../classgoat__vesc_1_1VescClient.html#aefbe4070b1ba83ddbd41de2231540f9e',1,'goat_vesc::VescClient']]],
  ['set_5fservo_5fpos_6',['set_servo_pos',['../classgoat__vesc_1_1VescClient.html#aa2b279ebe5dae920dd348d34b0bd0ace',1,'goat_vesc::VescClient']]],
  ['subscribe_5fimu_7',['subscribe_imu',['../classgoat__vesc_1_1VescClient.html#a9aa2051ea4288513f486b9d093caf2ea',1,'goat_vesc::VescClient']]],
  ['subscribe_5fmotor_5fstate_8',['subscribe_motor_state',['../classgoat__vesc_1_1VescClient.html#a238c970cbc3c3750b65cc14ca217b38f',1,'goat_vesc::VescClient']]],
  ['subscriptionhandle_9',['subscriptionhandle',['../classgoat__vesc_1_1VescClient_1_1SubscriptionHandle.html#a5d0d0ccf61491fe3e69720a442cc96f9',1,'goat_vesc::VescClient::SubscriptionHandle::SubscriptionHandle()=default'],['../classgoat__vesc_1_1VescClient_1_1SubscriptionHandle.html#abe8733d2293fa12de546b7026da33923',1,'goat_vesc::VescClient::SubscriptionHandle::SubscriptionHandle(SubscriptionHandle &amp;&amp;other) noexcept']]]
];
