var searchData=
[
  ['kmaxframedpacketbytes_0',['kMaxFramedPacketBytes',['../protocol__ids_8hpp.html#a45215109dfec25c226c23c71485f0665',1,'goat_vesc']]],
  ['kmaxpayloadbytes_1',['kMaxPayloadBytes',['../protocol__ids_8hpp.html#aa137776152aa007fb50b176f3a778101',1,'goat_vesc']]]
];
