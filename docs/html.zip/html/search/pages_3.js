var searchData=
[
  ['goat_5fvesc_0',['goat_vesc',['../index.html',1,'']]],
  ['goat_5fvesc_20architecture_20notes_1',['goat_vesc Architecture Notes',['../md_docs_2src_2ARCHITECTURE.html',1,'']]]
];
