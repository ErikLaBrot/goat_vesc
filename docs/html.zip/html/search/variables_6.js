var searchData=
[
  ['imu_5fpoll_5finterval_0',['imu_poll_interval',['../structgoat__vesc_1_1VescConfig.html#a6cfa8085e26d5155e0143581c49ed95a',1,'goat_vesc::VescConfig::imu_poll_interval'],['../structgoat__vesc_1_1VescClientConfigSnapshot.html#afde9bf32f5da6afb93d6c2ba6aa9d015',1,'goat_vesc::VescClientConfigSnapshot::imu_poll_interval']]]
];
