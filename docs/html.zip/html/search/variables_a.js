var searchData=
[
  ['pitch_0',['pitch',['../structgoat__vesc_1_1VescIMUData.html#ab688d5eca2bd119a54d5e15bf1bd572b',1,'goat_vesc::VescIMUData']]],
  ['poll_5fresponse_5ftimeout_1',['poll_response_timeout',['../structgoat__vesc_1_1VescConfig.html#a0c49428a9f95ca9bd16067fc9897da77',1,'goat_vesc::VescConfig::poll_response_timeout'],['../structgoat__vesc_1_1VescClientConfigSnapshot.html#a259bb223a3205550a66155464b5d3431',1,'goat_vesc::VescClientConfigSnapshot::poll_response_timeout']]]
];
