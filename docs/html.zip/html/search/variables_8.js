var searchData=
[
  ['mag_5fx_0',['mag_x',['../structgoat__vesc_1_1VescIMUData.html#a058043060e7d19ebc2d79e4ce16906d7',1,'goat_vesc::VescIMUData']]],
  ['mag_5fy_1',['mag_y',['../structgoat__vesc_1_1VescIMUData.html#a2fd878151dce3e409888c92f823c0464',1,'goat_vesc::VescIMUData']]],
  ['mag_5fz_2',['mag_z',['../structgoat__vesc_1_1VescIMUData.html#aa3bfc4f24910f3e61ffe1cb4ddff3136',1,'goat_vesc::VescIMUData']]],
  ['major_3',['major',['../structgoat__vesc_1_1FwVersion.html#ad76c131fc70e8d4bfad5109fa1890896',1,'goat_vesc::FwVersion']]],
  ['max_5fbrake_5fcurrent_4',['max_brake_current',['../structgoat__vesc_1_1VescConfig.html#a0c6f10d5bab0ac8d98897af245862b26',1,'goat_vesc::VescConfig::max_brake_current'],['../structgoat__vesc_1_1VescClientConfigSnapshot.html#abfcfae2bb0edfaaf3e25ccdc77b931a5',1,'goat_vesc::VescClientConfigSnapshot::max_brake_current']]],
  ['minor_5',['minor',['../structgoat__vesc_1_1FwVersion.html#ad4ff990fcfd41f106b79826c7dc80616',1,'goat_vesc::FwVersion']]],
  ['motor_5fpoll_5finterval_6',['motor_poll_interval',['../structgoat__vesc_1_1VescConfig.html#a82253645423f57bda9552bde4b14b16b',1,'goat_vesc::VescConfig::motor_poll_interval'],['../structgoat__vesc_1_1VescClientConfigSnapshot.html#a465f823d44b1dc1ee5147ab30d4c9549',1,'goat_vesc::VescClientConfigSnapshot::motor_poll_interval']]]
];
