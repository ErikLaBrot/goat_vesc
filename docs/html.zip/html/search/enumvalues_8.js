var searchData=
[
  ['long_0',['Long',['../protocol__ids_8hpp.html#a6b342601cc6e0b6392c58113f3647aeca8394f0347c184cf156ac5924dccb773b',1,'goat_vesc']]]
];
