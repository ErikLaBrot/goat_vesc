var searchData=
[
  ['stamp_5fns_0',['stamp_ns',['../structgoat__vesc_1_1VescMotorState.html#aa8a5aedfaa8d68c019a542478e5fff6e',1,'goat_vesc::VescMotorState::stamp_ns'],['../structgoat__vesc_1_1VescIMUData.html#a46e262b0731e64c833c377f246495bb4',1,'goat_vesc::VescIMUData::stamp_ns']]]
];
