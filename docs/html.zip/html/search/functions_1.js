var searchData=
[
  ['config_5fsnapshot_0',['config_snapshot',['../classgoat__vesc_1_1VescClient.html#a21dfea82e8fa698489137c5ceae00f4a',1,'goat_vesc::VescClient']]],
  ['connect_1',['connect',['../classgoat__vesc_1_1VescClient.html#a51c3b72e4a015d9e7b01db3fb62fad1c',1,'goat_vesc::VescClient']]]
];
