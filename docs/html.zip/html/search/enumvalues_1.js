var searchData=
[
  ['brakecurrent_0',['BrakeCurrent',['../types_8hpp.html#a0a3a877b0882d54b72c6962ff0c102f6a5cfa973d5fc5b4d5a8dd16fab85d7be6',1,'goat_vesc']]]
];
