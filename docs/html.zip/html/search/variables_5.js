var searchData=
[
  ['gyro_5fx_0',['gyro_x',['../structgoat__vesc_1_1VescIMUData.html#a72edcdfe422339eb486c48e931b76ab8',1,'goat_vesc::VescIMUData']]],
  ['gyro_5fy_1',['gyro_y',['../structgoat__vesc_1_1VescIMUData.html#aab73cbed7dff78570a6cea07d9e34fbd',1,'goat_vesc::VescIMUData']]],
  ['gyro_5fz_2',['gyro_z',['../structgoat__vesc_1_1VescIMUData.html#a2c76f351ec8a95eacfbe92e612c7e9f6',1,'goat_vesc::VescIMUData']]]
];
