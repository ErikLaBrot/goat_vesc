var searchData=
[
  ['latest_5fimu_0',['latest_imu',['../classgoat__vesc_1_1VescClient.html#ad03d52bef002bc0bd47165d6d2764890',1,'goat_vesc::VescClient']]],
  ['latest_5fmotor_5fstate_1',['latest_motor_state',['../classgoat__vesc_1_1VescClient.html#a1b6875c1ca67891b7abfc41cd7419755',1,'goat_vesc::VescClient']]]
];
