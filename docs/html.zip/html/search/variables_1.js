var searchData=
[
  ['baud_0',['baud',['../structgoat__vesc_1_1VescConfig.html#a3b3810633aaadf3b3ed7b5f9d7128067',1,'goat_vesc::VescConfig']]]
];
