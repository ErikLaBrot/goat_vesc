var searchData=
[
  ['_7esubscriptionhandle_0',['~SubscriptionHandle',['../classgoat__vesc_1_1VescClient_1_1SubscriptionHandle.html#a77a85b9a4bd2bc4270c8be4e391f061c',1,'goat_vesc::VescClient::SubscriptionHandle']]],
  ['_7evescclient_1',['~VescClient',['../classgoat__vesc_1_1VescClient.html#a9b329278dfc22c1f033b862c39111816',1,'goat_vesc::VescClient']]]
];
