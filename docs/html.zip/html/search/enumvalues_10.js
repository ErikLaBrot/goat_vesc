var searchData=
[
  ['watthours_0',['WattHours',['../protocol__ids_8hpp.html#ad0e5763b4186d49694fba40e821a3b90a9e1efe2403f86b19723ba090d216b46e',1,'goat_vesc']]],
  ['watthourscharged_1',['WattHoursCharged',['../protocol__ids_8hpp.html#ad0e5763b4186d49694fba40e821a3b90af7e796daa8fb89abac36263922eefc83',1,'goat_vesc']]],
  ['writenewappdata_2',['WriteNewAppData',['../protocol__ids_8hpp.html#a8ef58bdb88c3cab5bd7e80f07d5cc2cbaad532f3a5684f353395b5721ffd02ada',1,'goat_vesc']]]
];
