var searchData=
[
  ['notes_0',['notes',['../md_docs_2src_2ARCHITECTURE.html',1,'goat_vesc Architecture Notes'],['../index.html#autotoc_md5',1,'Release / Workflow Notes']]]
];
