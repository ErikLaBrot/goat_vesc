var searchData=
[
  ['request_5ffw_5fversion_0',['request_fw_version',['../classgoat__vesc_1_1VescClient.html#a4074f36781931a1ec8c4a1d4e614eb46',1,'goat_vesc::VescClient']]],
  ['reset_1',['reset',['../classgoat__vesc_1_1VescPacketParser.html#aa47e493e505cde6463597b69ef9f2049',1,'goat_vesc::VescPacketParser::reset()'],['../classgoat__vesc_1_1VescClient_1_1SubscriptionHandle.html#ae71ebf6a063f5ce603940f0deda78578',1,'goat_vesc::VescClient::SubscriptionHandle::reset()']]]
];
