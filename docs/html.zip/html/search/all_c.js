var searchData=
[
  ['mag_5fx_0',['mag_x',['../structgoat__vesc_1_1VescIMUData.html#a058043060e7d19ebc2d79e4ce16906d7',1,'goat_vesc::VescIMUData']]],
  ['mag_5fy_1',['mag_y',['../structgoat__vesc_1_1VescIMUData.html#a2fd878151dce3e409888c92f823c0464',1,'goat_vesc::VescIMUData']]],
  ['mag_5fz_2',['mag_z',['../structgoat__vesc_1_1VescIMUData.html#aa3bfc4f24910f3e61ffe1cb4ddff3136',1,'goat_vesc::VescIMUData']]],
  ['magx_3',['MagX',['../protocol__ids_8hpp.html#acac8566107a23d362d723086565773daaa01fb42d8c9455028a05dcaba9a28704',1,'goat_vesc']]],
  ['magy_4',['MagY',['../protocol__ids_8hpp.html#acac8566107a23d362d723086565773daa98049c54d38054486c462414b1eb6037',1,'goat_vesc']]],
  ['magz_5',['MagZ',['../protocol__ids_8hpp.html#acac8566107a23d362d723086565773daa77c3c16567bf868273a8dd35d35d01b0',1,'goat_vesc']]],
  ['major_6',['major',['../structgoat__vesc_1_1FwVersion.html#ad76c131fc70e8d4bfad5109fa1890896',1,'goat_vesc::FwVersion']]],
  ['manual_20tools_7',['manual tools',['../md_docs_2src_2OPERATOR__QUICK__REFERENCE.html#autotoc_md34',1,'Manual Tools'],['../index.html#autotoc_md6',1,'Manual Tools']]],
  ['matrix_8',['Protocol Support Matrix',['../md_docs_2src_2BRIDGE__READINESS__CHECKLIST.html#autotoc_md18',1,'']]],
  ['max_5fbrake_5fcurrent_9',['max_brake_current',['../structgoat__vesc_1_1VescClientConfigSnapshot.html#abfcfae2bb0edfaaf3e25ccdc77b931a5',1,'goat_vesc::VescClientConfigSnapshot::max_brake_current'],['../structgoat__vesc_1_1VescConfig.html#a0c6f10d5bab0ac8d98897af245862b26',1,'goat_vesc::VescConfig::max_brake_current']]],
  ['medium_10',['Medium',['../protocol__ids_8hpp.html#a6b342601cc6e0b6392c58113f3647aeca87f8a6ab85c9ced3702b4ea641ad4bb5',1,'goat_vesc']]],
  ['minor_11',['minor',['../structgoat__vesc_1_1FwVersion.html#ad4ff990fcfd41f106b79826c7dc80616',1,'goat_vesc::FwVersion']]],
  ['model_12',['model',['../md_docs_2src_2OPERATOR__QUICK__REFERENCE.html#autotoc_md33',1,'Configuration Model'],['../md_docs_2src_2ARCHITECTURE.html#autotoc_md12',1,'Watchdog and Safety Model']]],
  ['mostemps_13',['MosTemps',['../protocol__ids_8hpp.html#ad0e5763b4186d49694fba40e821a3b90a6f453cafd5b5d3ce42484c04de870798',1,'goat_vesc']]],
  ['motor_20control_14',['Motor Control',['../md_docs_2src_2BRIDGE__READINESS__CHECKLIST.html#autotoc_md19',1,'']]],
  ['motor_20telemetry_15',['Motor Telemetry',['../md_docs_2src_2OPERATOR__QUICK__REFERENCE.html#autotoc_md28',1,'']]],
  ['motor_5fpoll_5finterval_16',['motor_poll_interval',['../structgoat__vesc_1_1VescClientConfigSnapshot.html#a465f823d44b1dc1ee5147ab30d4c9549',1,'goat_vesc::VescClientConfigSnapshot::motor_poll_interval'],['../structgoat__vesc_1_1VescConfig.html#a82253645423f57bda9552bde4b14b16b',1,'goat_vesc::VescConfig::motor_poll_interval']]],
  ['motorstatecallback_17',['MotorStateCallback',['../classgoat__vesc_1_1VescClient.html#abe43789ef3dc3cd24f8e72fe9a9d22d0',1,'goat_vesc::VescClient']]],
  ['motortemp_18',['MotorTemp',['../protocol__ids_8hpp.html#ad0e5763b4186d49694fba40e821a3b90a8f0284699e8d56966f5685a60a702945',1,'goat_vesc']]]
];
