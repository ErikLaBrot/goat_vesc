var searchData=
[
  ['quat_5fw_0',['quat_w',['../structgoat__vesc_1_1VescIMUData.html#a62e5932fe5888978f3e199627627e81f',1,'goat_vesc::VescIMUData']]],
  ['quat_5fx_1',['quat_x',['../structgoat__vesc_1_1VescIMUData.html#a040a79ad67972b08764474620406d13e',1,'goat_vesc::VescIMUData']]],
  ['quat_5fy_2',['quat_y',['../structgoat__vesc_1_1VescIMUData.html#abf2b6c970df1c6930d5e738601b514a4',1,'goat_vesc::VescIMUData']]],
  ['quat_5fz_3',['quat_z',['../structgoat__vesc_1_1VescIMUData.html#a1daac6d9aa45a497ef76543461c772f3',1,'goat_vesc::VescIMUData']]],
  ['query_5fguard_5fwindow_4',['query_guard_window',['../structgoat__vesc_1_1VescConfig.html#a254f5773b7683a293639c278e2bb3a31',1,'goat_vesc::VescConfig::query_guard_window'],['../structgoat__vesc_1_1VescClientConfigSnapshot.html#a0743f67c5f834b56bdd776f3843368d4',1,'goat_vesc::VescClientConfigSnapshot::query_guard_window']]]
];
